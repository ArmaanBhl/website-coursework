#!/bin/bash

MYPASSWORD='DOG'
echo "Enter a password"
read Input
if [ $MYPASSWORD = $Input ] ; then
	echo "You have access"
else 
	echo "Access Denied"
fi
