#!/bin/bash

echo "1. $ ./q1-msg.sh"
echo "2. Hello! This is the first shell scripting exercise for module CO1101."
echo "3.The script is being run by user $(whoami)"
echo "4.The current directory is $(pwd)"

